#!/usr/bin/env python
from puremagic.main import command_line_entry

command_line_entry()
